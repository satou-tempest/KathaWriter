package com.katha.writer;

import android.app.Activity;
import android.app.AlertDialog;
import android.print.PrintManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.icu.text.BreakIterator;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;
import java.util.UUID;
import java.util.TimeZone;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.CRC32;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/**
 * Katha Writer v0.1-beta.
 * Local-first Android writing studio. Manuscript bodies are separate UTF-8 files;
 * SQLite stores folder/note/font metadata, so the app does not impose a word cap.
 */
public class MainActivity extends Activity {
    private static final int REQ_IMPORT_FONT = 1101;
    private static final int REQ_EXPORT_EPUB = 1102;

    private static final int BG = Color.rgb(13, 17, 25);
    private static final int PANEL = Color.rgb(23, 29, 41);
    private static final int PANEL_2 = Color.rgb(32, 40, 56);
    private static final int TEXT = Color.rgb(241, 242, 248);
    private static final int MUTED = Color.rgb(154, 165, 186);
    private static final int ACCENT = Color.rgb(182, 160, 255);
    private static final int BORDER = Color.rgb(48, 59, 80);

    private DbHelper db;
    private LinearLayout root;
    private LinearLayout noteList;
    private LinearLayout folderChips;
    private EditText searchInput;
    private long selectedFolderId = -1L; // -1 = all folders
    private long defaultFolderId;

    private boolean editing = false;
    private long currentNoteId = -1L;
    private String currentFileName = "";
    private String currentHtml = "<p></p>";
    private String currentPlainText = "";
    private String currentFontFamily = "";
    private String currentTitle = "Untitled";

    private WebView editorWebView;
    private EditText titleInput;
    private TextView wordCountView;
    private TextView charCountView;
    private TextView noSpaceCountView;
    private TextView saveStateView;
    private boolean editorReady = false;

    private final ExecutorService countExecutor = Executors.newSingleThreadExecutor();

    private boolean pendingEmbedFont = false;
    private String pendingEmbedFamily = "";

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        db = new DbHelper(this);
        defaultFolderId = db.ensureUnfiledFolder();
        showHome();
    }

    @Override
    protected void onPause() {
        if (editing && editorWebView != null && editorReady) {
            editorWebView.evaluateJavascript("window.forceSave && window.forceSave();", null);
        }
        super.onPause();
    }

    @Override
    public void onBackPressed() {
        if (editing) {
            closeEditorAfterSave();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (editorWebView != null) {
            editorWebView.removeJavascriptInterface("AndroidBridge");
            editorWebView.destroy();
        }
        countExecutor.shutdown();
        super.onDestroy();
    }

    // ---------------------------------------------------------------------
    // Home / folder / note management
    // ---------------------------------------------------------------------

    private void showHome() {
        editing = false;
        editorReady = false;
        currentNoteId = -1L;
        if (editorWebView != null) {
            editorWebView.removeJavascriptInterface("AndroidBridge");
            editorWebView.destroy();
            editorWebView = null;
        }

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);
        root.setPadding(dp(18), dp(16), dp(18), dp(12));

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);

        ImageView brandMark = new ImageView(this);
        brandMark.setImageResource(R.drawable.ic_katha_mark);
        brandMark.setPadding(dp(5), dp(5), dp(5), dp(5));
        brandMark.setBackground(round(PANEL_2, 14, BORDER, 1));
        header.addView(brandMark, marginParams(48, 48, 0, 0, 12, 0));

        LinearLayout brand = new LinearLayout(this);
        brand.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("KATHA WRITER", 20, TEXT, true);
        title.setLetterSpacing(0.035f);
        TextView subtitle = text("NOVEL STUDIO  ·  BETA 0.1.2", 9, MUTED, true);
        subtitle.setLetterSpacing(0.08f);
        brand.addView(title);
        brand.addView(subtitle);
        header.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));

        Button newFolder = smallButton("＋ Folder");
        newFolder.setOnClickListener(v -> promptCreateFolder());
        header.addView(newFolder, marginParams(-2, 42, 0, 0, 8, 0));
        Button newNote = smallButton("＋ Note");
        newNote.setOnClickListener(v -> createNote(selectedFolderId == -1L ? defaultFolderId : selectedFolderId));
        header.addView(newNote, marginParams(-2, 42, 0, 0, 0, 0));
        root.addView(header);

        TextView intro = text("Your manuscripts, neatly organized.", 13, MUTED, false);
        LinearLayout.LayoutParams introParams = new LinearLayout.LayoutParams(-1, -2);
        introParams.topMargin = dp(10);
        root.addView(intro, introParams);

        searchInput = new EditText(this);
        searchInput.setSingleLine(true);
        searchInput.setTextColor(TEXT);
        searchInput.setHintTextColor(MUTED);
        searchInput.setHint("Search titles and manuscript text");
        searchInput.setTextSize(14);
        searchInput.setPadding(dp(14), 0, dp(14), 0);
        searchInput.setBackground(round(PANEL, 14, BORDER, 1));
        LinearLayout.LayoutParams searchParams = new LinearLayout.LayoutParams(-1, dp(48));
        searchParams.topMargin = dp(16);
        root.addView(searchInput, searchParams);

        TextView folderLabel = text("FOLDERS  ·  LONG-PRESS TO MANAGE", 10, MUTED, true);
        folderLabel.setLetterSpacing(0.12f);
        LinearLayout.LayoutParams flp = new LinearLayout.LayoutParams(-1, -2);
        flp.topMargin = dp(18);
        root.addView(folderLabel, flp);

        HorizontalScrollView folderScroll = new HorizontalScrollView(this);
        folderScroll.setHorizontalScrollBarEnabled(false);
        folderChips = new LinearLayout(this);
        folderChips.setOrientation(LinearLayout.HORIZONTAL);
        folderChips.setPadding(0, dp(9), 0, dp(5));
        folderScroll.addView(folderChips);
        root.addView(folderScroll, new LinearLayout.LayoutParams(-1, dp(64)));

        LinearLayout listHeader = new LinearLayout(this);
        listHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView notesTitle = text("YOUR NOTES", 10, MUTED, true);
        notesTitle.setLetterSpacing(0.12f);
        listHeader.addView(notesTitle, new LinearLayout.LayoutParams(0, -2, 1));
        TextView sortLabel = text("Saved on this device", 10, MUTED, false);
        listHeader.addView(sortLabel);
        LinearLayout.LayoutParams lhp = new LinearLayout.LayoutParams(-1, -2);
        lhp.topMargin = dp(7);
        root.addView(listHeader, lhp);

        ScrollView notesScroll = new ScrollView(this);
        notesScroll.setFillViewport(false);
        notesScroll.setClipToPadding(false);
        noteList = new LinearLayout(this);
        noteList.setOrientation(LinearLayout.VERTICAL);
        noteList.setPadding(0, dp(10), 0, dp(26));
        notesScroll.addView(noteList);
        LinearLayout.LayoutParams nsp = new LinearLayout.LayoutParams(-1, 0, 1);
        nsp.topMargin = dp(3);
        root.addView(notesScroll, nsp);

        searchInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) { renderNotes(); }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        setContentView(root);
        renderFolders();
        renderNotes();
    }

    private void renderFolders() {
        folderChips.removeAllViews();
        addFolderChip("All notes", -1L, null);
        for (Folder folder : db.getFolders()) {
            addFolderChip(folder.name, folder.id, folder);
        }
    }

    private void addFolderChip(String name, long id, Folder folder) {
        boolean selected = id == selectedFolderId;
        LinearLayout chip = new LinearLayout(this);
        chip.setOrientation(LinearLayout.HORIZONTAL);
        chip.setGravity(Gravity.CENTER_VERTICAL);
        chip.setPadding(dp(12), 0, dp(13), 0);
        chip.setBackground(round(selected ? Color.rgb(55, 47, 83) : PANEL,
                15, selected ? ACCENT : BORDER, selected ? 1 : 1));

        ImageView icon = new ImageView(this);
        icon.setImageResource(folder == null ? R.drawable.ic_all_notes_katha : R.drawable.ic_folder_katha);
        icon.setColorFilter(selected ? ACCENT : Color.rgb(169, 151, 235));
        chip.addView(icon, marginParams(27, 27, 0, 0, 8, 0));

        TextView label = text(name, 12, selected ? TEXT : Color.rgb(220, 225, 238), true);
        label.setMaxLines(1);
        label.setEllipsize(android.text.TextUtils.TruncateAt.END);
        chip.addView(label, new LinearLayout.LayoutParams(-2, -2));

        int count = db.getNotes(id, "").size();
        TextView badge = text(String.valueOf(count), 10, selected ? BG : MUTED, true);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(dp(7), dp(3), dp(7), dp(3));
        badge.setBackground(round(selected ? ACCENT : PANEL_2, 10, Color.TRANSPARENT, 0));
        LinearLayout.LayoutParams badgeParams = marginParams(-2, -2, 8, 0, 0, 0);
        chip.addView(badge, badgeParams);

        LinearLayout.LayoutParams p = marginParams(-2, 48, 0, 0, 9, 0);
        folderChips.addView(chip, p);
        chip.setOnClickListener(v -> {
            selectedFolderId = id;
            renderFolders();
            renderNotes();
        });
        if (folder != null) {
            chip.setOnLongClickListener(v -> {
                showFolderActions(folder);
                return true;
            });
        }
    }

    private void renderNotes() {
        if (noteList == null) return;
        noteList.removeAllViews();
        String query = searchInput == null ? "" : searchInput.getText().toString().trim();
        ArrayList<Note> notes = db.getNotes(selectedFolderId, query);
        if (notes.isEmpty()) {
            LinearLayout empty = new LinearLayout(this);
            empty.setGravity(Gravity.CENTER);
            empty.setOrientation(LinearLayout.VERTICAL);
            empty.setPadding(dp(15), dp(48), dp(15), dp(42));
            TextView icon = text("✧", 38, ACCENT, true);
            icon.setGravity(Gravity.CENTER);
            TextView heading = text(query.isEmpty() ? "No notes here yet" : "No matching notes", 17, TEXT, true);
            heading.setGravity(Gravity.CENTER);
            TextView detail = text(query.isEmpty() ? "Create a note and start writing." : "Try another title or keyword.", 12, MUTED, false);
            detail.setGravity(Gravity.CENTER);
            empty.addView(icon);
            empty.addView(heading);
            empty.addView(detail);
            noteList.addView(empty);
            return;
        }
        for (Note note : notes) {
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(17), dp(15), dp(17), dp(15));
            card.setBackground(round(PANEL, 18, BORDER, 1));

            LinearLayout top = new LinearLayout(this);
            top.setGravity(Gravity.CENTER_VERTICAL);
            TextView title = text(note.title.isEmpty() ? "Untitled" : note.title, 16, TEXT, true);
            title.setMaxLines(1);
            title.setEllipsize(android.text.TextUtils.TruncateAt.END);
            top.addView(title, new LinearLayout.LayoutParams(0, -2, 1));
            TextView more = text("•••", 15, MUTED, true);
            more.setPadding(dp(10), dp(4), 0, dp(4));
            more.setOnClickListener(v -> showNoteActions(note));
            top.addView(more);
            card.addView(top);

            String preview = note.preview == null ? "" : note.preview.replace('\n', ' ').trim();
            if (preview.length() > 130) preview = preview.substring(0, 130) + "…";
            TextView body = text(preview.isEmpty() ? "Empty note" : preview, 12, MUTED, false);
            body.setMaxLines(2);
            LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(-1, -2);
            bp.topMargin = dp(7);
            card.addView(body, bp);

            LinearLayout meta = new LinearLayout(this);
            meta.setGravity(Gravity.CENTER_VERTICAL);
            TextView count = text(formatCount(note.preview), 10, ACCENT, true);
            TextView date = text(formatDate(note.updatedAt), 10, MUTED, false);
            meta.addView(count, new LinearLayout.LayoutParams(0, -2, 1));
            meta.addView(date);
            LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
            mp.topMargin = dp(11);
            card.addView(meta, mp);

            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1, -2);
            cp.bottomMargin = dp(9);
            noteList.addView(card, cp);
            card.setOnClickListener(v -> openNote(note.id));
            card.setOnLongClickListener(v -> { showNoteActions(note); return true; });
        }
    }

    private String formatCount(String value) {
        if (value == null || value.isEmpty()) return "0 characters";
        return String.format(Locale.getDefault(), "%,d characters", value.codePointCount(0, value.length()));
    }

    private String formatDate(long millis) {
        return new SimpleDateFormat("MMM d · h:mm a", Locale.getDefault()).format(new Date(millis));
    }

    private void promptCreateFolder() {
        EditText input = dialogInput("Folder name", "New folder");
        new AlertDialog.Builder(this).setTitle("Create folder").setView(input)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Create", (d, w) -> {
                    String name = input.getText().toString().trim();
                    if (name.isEmpty()) return;
                    db.createFolder(name);
                    renderFolders();
                    renderNotes();
                }).show();
    }

    private void showFolderActions(Folder folder) {
        if (folder.name.equals("Unfiled")) {
            toast("Unfiled is a system folder and cannot be renamed or deleted.");
            return;
        }
        String[] actions = {"Rename folder", "Delete folder"};
        new AlertDialog.Builder(this).setTitle(folder.name).setItems(actions, (d, which) -> {
            if (which == 0) {
                EditText input = dialogInput("Folder name", folder.name);
                new AlertDialog.Builder(this).setTitle("Rename folder").setView(input)
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Save", (dd, ww) -> {
                            String name = input.getText().toString().trim();
                            if (!name.isEmpty()) db.renameFolder(folder.id, name);
                            renderFolders(); renderNotes();
                        }).show();
            } else {
                new AlertDialog.Builder(this).setTitle("Delete “" + folder.name + "”? ")
                        .setMessage("Notes inside this folder will be moved to Unfiled. Their contents will not be deleted.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete folder", (dd, ww) -> {
                            db.moveFolderNotes(folder.id, defaultFolderId);
                            db.deleteFolder(folder.id);
                            if (selectedFolderId == folder.id) selectedFolderId = -1L;
                            renderFolders(); renderNotes();
                        }).show();
            }
        }).show();
    }

    private void showNoteActions(Note note) {
        String[] actions = {"Rename", "Move to folder", "Delete note"};
        new AlertDialog.Builder(this).setTitle(note.title).setItems(actions, (d, which) -> {
            if (which == 0) {
                EditText input = dialogInput("Note title", note.title);
                new AlertDialog.Builder(this).setTitle("Rename note").setView(input)
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Save", (dd, ww) -> {
                            String name = input.getText().toString().trim();
                            if (!name.isEmpty()) db.renameNote(note.id, name);
                            renderNotes();
                        }).show();
            } else if (which == 1) {
                ArrayList<Folder> folders = db.getFolders();
                String[] names = new String[folders.size()];
                for (int i = 0; i < folders.size(); i++) names[i] = folders.get(i).name;
                new AlertDialog.Builder(this).setTitle("Move note to").setItems(names, (dd, index) -> {
                    if (index >= 0 && index < folders.size()) {
                        db.moveNote(note.id, folders.get(index).id);
                        renderNotes();
                    }
                }).show();
            } else {
                new AlertDialog.Builder(this).setTitle("Delete note?")
                        .setMessage("This permanently deletes this note from this device.")
                        .setNegativeButton("Cancel", null)
                        .setPositiveButton("Delete", (dd, ww) -> {
                            Note full = db.getNote(note.id);
                            if (full != null) new File(getFilesDir(), "manuscripts/" + full.fileName).delete();
                            db.deleteNote(note.id);
                            renderNotes();
                        }).show();
            }
        }).show();
    }

    private void createNote(long folderId) {
        long id = db.createNote(folderId, "Untitled");
        Note note = db.getNote(id);
        if (note != null) {
            writeManuscript(note.fileName, "<p></p>");
            openNote(id);
        }
    }

    // ---------------------------------------------------------------------
    // Editor
    // ---------------------------------------------------------------------

    private void openNote(long id) {
        Note note = db.getNote(id);
        if (note == null) return;
        editing = true;
        currentNoteId = note.id;
        currentFileName = note.fileName;
        currentTitle = note.title == null || note.title.trim().isEmpty() ? "Untitled" : note.title;
        currentFontFamily = note.fontFamily == null ? "" : note.fontFamily;
        currentHtml = readManuscript(currentFileName);
        currentPlainText = note.preview == null ? "" : note.preview;
        editorReady = false;
        buildEditorUi();
    }

    private void buildEditorUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(BG);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setPadding(dp(8), dp(7), dp(10), dp(7));
        header.setBackgroundColor(BG);

        Button back = iconButton("‹");
        back.setOnClickListener(v -> closeEditorAfterSave());
        header.addView(back, new LinearLayout.LayoutParams(dp(42), dp(42)));

        titleInput = new EditText(this);
        titleInput.setSingleLine(true);
        titleInput.setText(currentTitle);
        titleInput.setTextColor(TEXT);
        titleInput.setHintTextColor(MUTED);
        titleInput.setTextSize(16);
        titleInput.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        titleInput.setPadding(dp(8), 0, dp(4), 0);
        titleInput.setBackgroundColor(Color.TRANSPARENT);
        header.addView(titleInput, new LinearLayout.LayoutParams(0, dp(46), 1));

        Button menu = iconButton("⋮");
        menu.setOnClickListener(v -> showEditorMenu(menu));
        header.addView(menu, new LinearLayout.LayoutParams(dp(42), dp(42)));
        root.addView(header);

        View line = new View(this);
        line.setBackgroundColor(BORDER);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));

        editorWebView = new WebView(this);
        editorWebView.setBackgroundColor(BG);
        WebSettings settings = editorWebView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDefaultTextEncodingName("UTF-8");
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        editorWebView.setWebChromeClient(new WebChromeClient());
        editorWebView.addJavascriptInterface(new EditorBridge(), "AndroidBridge");
        editorWebView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                // Keep the JS bridge confined to the bundled editor page; never navigate to websites.
                return true;
            }
            @Override public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                editorReady = true;
                String html = JSONObject.quote(currentHtml);
                String title = JSONObject.quote(currentTitle);
                String font = JSONObject.quote(currentFontFamily);
                view.evaluateJavascript("window.loadDocument(" + html + "," + title + "," + font + ");", null);
                view.evaluateJavascript("window.setFonts && window.setFonts();", null);
            }
        });
        LinearLayout.LayoutParams webParams = new LinearLayout.LayoutParams(-1, 0, 1);
        root.addView(editorWebView, webParams);

        LinearLayout status = new LinearLayout(this);
        status.setOrientation(LinearLayout.HORIZONTAL);
        status.setGravity(Gravity.CENTER_VERTICAL);
        status.setPadding(dp(12), dp(8), dp(12), dp(8));
        status.setBackgroundColor(PANEL);
        wordCountView = text("Words 0", 11, ACCENT, true);
        charCountView = text("Chars 0", 11, TEXT, true);
        noSpaceCountView = text("No spaces 0", 11, MUTED, false);
        saveStateView = text("Saved locally", 10, MUTED, false);
        status.addView(wordCountView, new LinearLayout.LayoutParams(0, -2, 1));
        status.addView(charCountView, new LinearLayout.LayoutParams(0, -2, 1));
        status.addView(noSpaceCountView, new LinearLayout.LayoutParams(0, -2, 1));
        status.addView(saveStateView);
        root.addView(status);

        titleInput.addTextChangedListener(new android.text.TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                currentTitle = s.toString();
                if (editorWebView != null && editorReady) {
                    editorWebView.evaluateJavascript("window.setDocTitle(" + JSONObject.quote(currentTitle) + ");", null);
                }
            }
            @Override public void afterTextChanged(android.text.Editable s) {}
        });

        setContentView(root);
        editorWebView.loadUrl("file:///android_asset/editor.html");
    }

    private void showEditorMenu(View anchor) {
        PopupMenu popup = new PopupMenu(this, anchor);
        popup.getMenu().add("Save now");
        popup.getMenu().add("Import custom font (.ttf / .otf)");
        popup.getMenu().add("Manage imported fonts");
        popup.getMenu().add("Export as PDF");
        popup.getMenu().add("Export as EPUB");
        popup.getMenu().add("Delete this note");
        popup.setOnMenuItemClickListener(item -> {
            String label = item.getTitle().toString();
            if (label.equals("Save now")) saveEditorNow();
            else if (label.startsWith("Import")) importFont();
            else if (label.startsWith("Manage")) manageFonts();
            else if (label.contains("PDF")) exportPdf();
            else if (label.contains("EPUB")) prepareEpubExport();
            else if (label.startsWith("Delete")) deleteCurrentNote();
            return true;
        });
        popup.show();
    }

    private void saveEditorNow() {
        if (editorWebView != null && editorReady) {
            editorWebView.evaluateJavascript("window.forceSave && window.forceSave();", result -> toast("Saved on this device."));
        } else if (currentNoteId > 0) {
            db.renameNote(currentNoteId, currentTitle);
            toast("Saved on this device.");
        }
    }

    private void closeEditorAfterSave() {
        if (editorWebView != null && editorReady) {
            editorWebView.evaluateJavascript("window.forceSave && window.forceSave();", result -> showHome());
        } else {
            showHome();
        }
    }

    private void persistDocument(String title, String html, String plain, String font) {
        if (currentNoteId <= 0 || currentFileName.isEmpty()) return;
        String safeTitle = title == null || title.trim().isEmpty() ? "Untitled" : title.trim();
        if (!writeManuscript(currentFileName, html == null ? "<p></p>" : html)) return;
        db.updateNote(currentNoteId, safeTitle, plain == null ? "" : plain, font == null ? "" : font);
        currentTitle = safeTitle;
        currentHtml = html == null ? "<p></p>" : html;
        currentPlainText = plain == null ? "" : plain;
        currentFontFamily = font == null ? "" : font;
        runOnUiThread(() -> {
            if (saveStateView != null) {
                saveStateView.setText("Saved");
                saveStateView.setTextColor(ACCENT);
            }
        });
    }

    private void updateCounts(String text) {
        if (text == null) text = "";
        final String source = text;
        countExecutor.execute(() -> {
            int words = countWordsMyanmarAware(source);
            // Count grapheme clusters rather than raw UTF-16/code points; Burmese vowels and marks
            // often combine with a base character into one user-perceived character.
            BreakIterator characters = BreakIterator.getCharacterInstance(Locale.forLanguageTag("my"));
            characters.setText(source);
            int chars = 0;
            int noSpaces = 0;
            int charStart = characters.first();
            for (int charEnd = characters.next(); charEnd != BreakIterator.DONE; charStart = charEnd, charEnd = characters.next()) {
                chars++;
                boolean whitespaceOnly = true;
                for (int i = charStart; i < charEnd;) {
                    int cp = source.codePointAt(i);
                    if (!Character.isWhitespace(cp)) whitespaceOnly = false;
                    i += Character.charCount(cp);
                }
                if (!whitespaceOnly) noSpaces++;
            }
            final int w = words, c = chars, ns = noSpaces;
            runOnUiThread(() -> {
                if (wordCountView != null) wordCountView.setText("Words " + String.format(Locale.getDefault(), "%,d", w));
                if (charCountView != null) charCountView.setText("Chars " + String.format(Locale.getDefault(), "%,d", c));
                if (noSpaceCountView != null) noSpaceCountView.setText("No spaces " + String.format(Locale.getDefault(), "%,d", ns));
            });
        });
    }

    /** ICU's Myanmar dictionary word-break iterator; not a whitespace-only counter. */
    private int countWordsMyanmarAware(String value) {
        if (value.isEmpty()) return 0;
        BreakIterator iterator = BreakIterator.getWordInstance(Locale.forLanguageTag("my"));
        iterator.setText(value);
        int count = 0;
        int start = iterator.first();
        for (int end = iterator.next(); end != BreakIterator.DONE; start = end, end = iterator.next()) {
            boolean hasWordCharacter = false;
            for (int i = start; i < end;) {
                int cp = value.codePointAt(i);
                if (Character.isLetterOrDigit(cp)) { hasWordCharacter = true; break; }
                i += Character.charCount(cp);
            }
            if (hasWordCharacter) count++;
        }
        return count;
    }

    // ---------------------------------------------------------------------
    // Custom font management
    // ---------------------------------------------------------------------

    private void importFont() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"font/ttf", "font/otf", "application/x-font-ttf", "application/vnd.ms-opentype", "application/octet-stream"});
        intent.putExtra(Intent.EXTRA_TITLE, "Choose a .ttf or .otf font");
        startActivityForResult(intent, REQ_IMPORT_FONT);
    }

    private void handleFontImport(Uri uri) {
        try {
            String displayName = queryDisplayName(uri);
            String lower = displayName.toLowerCase(Locale.ROOT);
            String extension;
            if (lower.endsWith(".ttf")) extension = ".ttf";
            else if (lower.endsWith(".otf")) extension = ".otf";
            else {
                toast("Please choose a .ttf or .otf file.");
                return;
            }
            File fontsDir = new File(getFilesDir(), "fonts");
            if (!fontsDir.exists() && !fontsDir.mkdirs()) throw new IllegalStateException("Could not create font folder");
            String storedName = UUID.randomUUID().toString().replace("-", "") + extension;
            File target = new File(fontsDir, storedName);
            try (InputStream in = getContentResolver().openInputStream(uri);
                 OutputStream out = new FileOutputStream(target)) {
                if (in == null) throw new IllegalStateException("Could not read selected font");
                byte[] buffer = new byte[8192];
                int read;
                while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            }
            long length = target.length();
            if (length < 1024 || length > 15L * 1024L * 1024L) {
                target.delete();
                toast("That font file looks invalid or is larger than 15 MB.");
                return;
            }
            try {
                Typeface.createFromFile(target); // Reject files that are not parseable font files.
            } catch (Exception invalidFont) {
                target.delete();
                toast("Android could not read that font file.");
                return;
            }
            String label = displayName.substring(0, displayName.length() - extension.length());
            String family = "KathaFont_" + UUID.randomUUID().toString().substring(0, 8).replace("-", "");
            db.addFont(family, label, storedName);
            if (editorWebView != null && editorReady) editorWebView.evaluateJavascript("window.setFonts && window.setFonts();", null);
            toast("Font imported: " + label);
        } catch (Exception e) {
            toast("Font import failed: " + e.getMessage());
        }
    }

    private void manageFonts() {
        ArrayList<FontInfo> fonts = db.getFonts();
        if (fonts.isEmpty()) {
            new AlertDialog.Builder(this).setTitle("Imported fonts")
                    .setMessage("No custom fonts imported yet. Import .ttf or .otf files from your device.")
                    .setPositiveButton("OK", null).show();
            return;
        }
        String[] names = new String[fonts.size()];
        for (int i = 0; i < fonts.size(); i++) names[i] = fonts.get(i).label;
        new AlertDialog.Builder(this).setTitle("Imported fonts · tap to remove")
                .setItems(names, (d, which) -> {
                    FontInfo font = fonts.get(which);
                    new AlertDialog.Builder(this).setTitle("Remove “" + font.label + "”? ")
                            .setMessage("This removes the font from Katha. Existing text remains; it will use a fallback font if the font is unavailable.")
                            .setNegativeButton("Cancel", null)
                            .setPositiveButton("Remove", (dd, ww) -> {
                                new File(new File(getFilesDir(), "fonts"), font.fileName).delete();
                                db.deleteFont(font.family);
                                if (font.family.equals(currentFontFamily)) {
                                    currentFontFamily = "";
                                    if (editorWebView != null && editorReady) editorWebView.evaluateJavascript("window.setDefaultFontForNote && window.setDefaultFontForNote('');", null);
                                }
                                if (editorWebView != null && editorReady) editorWebView.evaluateJavascript("window.setFonts && window.setFonts();", null);
                            }).show();
                }).show();
    }

    // ---------------------------------------------------------------------
    // PDF / EPUB export
    // ---------------------------------------------------------------------

    private void exportPdf() {
        if (editorWebView == null || !editorReady) return;
        editorWebView.evaluateJavascript("window.forceSave && window.forceSave();", result -> {
            try {
                PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                if (printManager == null) throw new IllegalStateException("Printing service unavailable");
                String name = currentTitle == null || currentTitle.trim().isEmpty() ? "Katha manuscript" : currentTitle.trim();
                printManager.print("Katha - " + name,
                        editorWebView.createPrintDocumentAdapter("Katha - " + name),
                        new android.print.PrintAttributes.Builder()
                                .setMediaSize(android.print.PrintAttributes.MediaSize.ISO_A4)
                                .setResolution(new android.print.PrintAttributes.Resolution("katha", "Katha", 300, 300))
                                .setMinMargins(android.print.PrintAttributes.Margins.NO_MARGINS)
                                .build());
            } catch (Exception e) {
                toast("Could not open PDF export: " + e.getMessage());
            }
        });
    }

    private void prepareEpubExport() {
        if (editorWebView == null || !editorReady) return;
        editorWebView.evaluateJavascript("window.forceSave && window.forceSave();", result -> showEpubOptions());
    }

    private void showEpubOptions() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(10), dp(20), dp(4));
        TextView explanation = text("EPUB uses reflowable pages, so readers can change text size and layout.", 13, MUTED, false);
        box.addView(explanation);

        CheckBox embed = new CheckBox(this);
        embed.setText("Embed imported fonts used in this manuscript");
        embed.setTextColor(TEXT);
        embed.setTextSize(13);
        ArrayList<FontInfo> availableFonts = db.getFonts();
        embed.setEnabled(!availableFonts.isEmpty());
        embed.setChecked(false);
        box.addView(embed);
        TextView warning = text("All used imported fonts will be included. Only enable this when each font licence permits redistribution. The default is off.", 11, MUTED, false);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(-1, -2);
        wp.topMargin = dp(5);
        box.addView(warning, wp);

        new AlertDialog.Builder(this).setTitle("Export EPUB").setView(box)
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Continue", (d, w) -> {
                    pendingEmbedFont = embed.isChecked() && !availableFonts.isEmpty();
                    pendingEmbedFamily = pendingEmbedFont ? "*" : "";
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/epub+zip");
                    intent.putExtra(Intent.EXTRA_TITLE, safeFileName(currentTitle) + ".epub");
                    startActivityForResult(intent, REQ_EXPORT_EPUB);
                }).show();
    }

    private void writeEpub(Uri destination) {
        try {
            Note note = db.getNote(currentNoteId);
            String html = note == null ? currentHtml : readManuscript(note.fileName);
            String title = currentTitle == null || currentTitle.trim().isEmpty() ? "Untitled" : currentTitle.trim();
            ArrayList<FontInfo> embeddedFonts = new ArrayList<>();
            if (pendingEmbedFont) {
                for (FontInfo candidate : db.getFonts()) {
                    boolean usedAsDefault = candidate.family.equals(currentFontFamily);
                    boolean usedInline = html != null && html.contains(candidate.family);
                    if (usedAsDefault || usedInline) embeddedFonts.add(candidate);
                }
            }
            try (OutputStream raw = getContentResolver().openOutputStream(destination);
                 ZipOutputStream zip = new ZipOutputStream(raw)) {
                if (raw == null) throw new IllegalStateException("Could not open destination");
                byte[] mime = "application/epub+zip".getBytes(StandardCharsets.US_ASCII);
                ZipEntry mimeEntry = new ZipEntry("mimetype");
                mimeEntry.setMethod(ZipEntry.STORED);
                mimeEntry.setSize(mime.length);
                mimeEntry.setCompressedSize(mime.length);
                CRC32 crc = new CRC32(); crc.update(mime); mimeEntry.setCrc(crc.getValue());
                zip.putNextEntry(mimeEntry); zip.write(mime); zip.closeEntry();

                putZipText(zip, "META-INF/container.xml",
                        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<container version=\"1.0\" xmlns=\"urn:oasis:names:tc:opendocument:xmlns:container\">" +
                        "<rootfiles><rootfile full-path=\"OEBPS/content.opf\" media-type=\"application/oebps-package+xml\"/></rootfiles></container>");

                StringBuilder fontManifest = new StringBuilder();
                StringBuilder fontCss = new StringBuilder();
                int fontIndex = 0;
                for (FontInfo embedded : embeddedFonts) {
                    String ext = embedded.fileName.toLowerCase(Locale.ROOT).endsWith(".otf") ? ".otf" : ".ttf";
                    String fontHref = "fonts/katha-font-" + fontIndex + ext;
                    byte[] fontBytes = readBytes(new File(new File(getFilesDir(), "fonts"), embedded.fileName));
                    zip.putNextEntry(new ZipEntry("OEBPS/" + fontHref));
                    zip.write(fontBytes);
                    zip.closeEntry();
                    String media = ext.equals(".otf") ? "font/otf" : "font/ttf";
                    fontManifest.append("<item id=\"custom-font-").append(fontIndex).append("\" href=\"")
                            .append(fontHref).append("\" media-type=\"").append(media).append("\"/>");
                    fontCss.append("@font-face{font-family:'").append(cssEscape(embedded.family))
                            .append("';src:url('").append(fontHref).append("');}");
                    fontIndex++;
                }
                String defaultFontCss = currentFontFamily != null && !currentFontFamily.isEmpty()
                        ? "'" + cssEscape(currentFontFamily) + "'," : "";
                String css = "body{font-family:" + defaultFontCss + "serif;line-height:1.8;margin:5%;color:#111;}h1,h2,h3{line-height:1.3;}p{margin:0 0 1em;}" + fontCss;
                putZipText(zip, "OEBPS/styles.css", css);
                putZipText(zip, "OEBPS/nav.xhtml", "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<html xmlns=\"http://www.w3.org/1999/xhtml\" xmlns:epub=\"http://www.idpf.org/2007/ops\" lang=\"my\" xml:lang=\"my\"><head><title>Contents</title><link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\"/></head><body><nav epub:type=\"toc\" id=\"toc\"><h1>Contents</h1><ol><li><a href=\"chapter.xhtml\">" + xmlEscape(title) + "</a></li></ol></nav></body></html>");

                String xhtmlBody = toXhtmlBody(html);
                String chapter = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<html xmlns=\"http://www.w3.org/1999/xhtml\" lang=\"my\" xml:lang=\"my\"><head><title>" + xmlEscape(title) +
                        "</title><meta charset=\"utf-8\"/><link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\"/></head><body><h1>" + xmlEscape(title) + "</h1>" + xhtmlBody + "</body></html>";
                putZipText(zip, "OEBPS/chapter.xhtml", chapter);

                SimpleDateFormat modifiedFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US);
                modifiedFormat.setTimeZone(TimeZone.getTimeZone("UTC"));
                String modified = modifiedFormat.format(new Date());
                String opf = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" +
                        "<package xmlns=\"http://www.idpf.org/2007/opf\" unique-identifier=\"bookid\" version=\"3.0\" xml:lang=\"my\">" +
                        "<metadata xmlns:dc=\"http://purl.org/dc/elements/1.1/\"><dc:identifier id=\"bookid\">urn:uuid:" + UUID.randomUUID() + "</dc:identifier><dc:title>" + xmlEscape(title) +
                        "</dc:title><dc:language>my</dc:language><meta property=\"dcterms:modified\">" + modified + "</meta></metadata>" +
                        "<manifest><item id=\"nav\" href=\"nav.xhtml\" media-type=\"application/xhtml+xml\" properties=\"nav\"/><item id=\"chapter\" href=\"chapter.xhtml\" media-type=\"application/xhtml+xml\"/><item id=\"css\" href=\"styles.css\" media-type=\"text/css\"/>" + fontManifest + "</manifest><spine><itemref idref=\"chapter\"/></spine></package>";
                putZipText(zip, "OEBPS/content.opf", opf);
            }
            toast("EPUB exported.");
        } catch (Exception e) {
            toast("EPUB export failed: " + e.getMessage());
        }
    }

    private String toXhtmlBody(String html) {
        if (html == null || html.trim().isEmpty()) return "<p></p>";
        String result = html;
        result = result.replaceAll("(?i)<br\\s*>", "<br />");
        result = result.replaceAll("(?i)<hr\\s*>", "<hr />");
        result = result.replace("&nbsp;", "&#160;");
        // WebView serializes text and attributes as escaped HTML; this normalizes common empty tags.
        result = result.replaceAll("(?i)<(img|input)([^>]*)>", "<$1$2 />");
        return result;
    }

    private void putZipText(ZipOutputStream zip, String path, String value) throws Exception {
        zip.putNextEntry(new ZipEntry(path));
        zip.write(value.getBytes(StandardCharsets.UTF_8));
        zip.closeEntry();
    }

    private byte[] readBytes(File file) throws Exception {
        try (InputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
            return out.toByteArray();
        }
    }

    private String xmlEscape(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace("\"", "&quot;").replace("'", "&apos;");
    }

    private String cssEscape(String value) {
        if (value == null) return "KathaFont";
        return value.replace("\\", "").replace("'", "").replace("\"", "").replace(";", "");
    }

    private void deleteCurrentNote() {
        new AlertDialog.Builder(this).setTitle("Delete this note?")
                .setMessage("This permanently deletes the manuscript from this device.")
                .setNegativeButton("Cancel", null)
                .setPositiveButton("Delete", (d, w) -> {
                    new File(getFilesDir(), "manuscripts/" + currentFileName).delete();
                    db.deleteNote(currentNoteId);
                    showHome();
                }).show();
    }

    // ---------------------------------------------------------------------
    // Activity results / storage helpers
    // ---------------------------------------------------------------------

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == REQ_IMPORT_FONT) handleFontImport(uri);
        else if (requestCode == REQ_EXPORT_EPUB) writeEpub(uri);
    }

    private String queryDisplayName(Uri uri) {
        String name = "font.ttf";
        try (Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = cursor.getString(idx);
            }
        } catch (Exception ignored) {}
        return name == null ? "font.ttf" : name;
    }

    private boolean writeManuscript(String fileName, String html) {
        try {
            File dir = new File(getFilesDir(), "manuscripts");
            if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Could not create manuscript storage");
            File target = new File(dir, fileName);
            File temp = new File(dir, fileName + ".tmp");
            try (FileOutputStream out = new FileOutputStream(temp)) {
                out.write((html == null ? "<p></p>" : html).getBytes(StandardCharsets.UTF_8));
                out.flush();
                out.getFD().sync();
            }
            try {
                java.nio.file.Files.move(temp.toPath(), target.toPath(),
                        java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                        java.nio.file.StandardCopyOption.ATOMIC_MOVE);
            } catch (Exception atomicMoveError) {
                java.nio.file.Files.move(temp.toPath(), target.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING);
            }
            return true;
        } catch (Exception e) {
            runOnUiThread(() -> toast("Save error: " + e.getMessage()));
            return false;
        }
    }

    private String readManuscript(String fileName) {
        try {
            File file = new File(new File(getFilesDir(), "manuscripts"), fileName);
            if (!file.exists()) return "<p></p>";
            try (InputStream in = new FileInputStream(file); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int n;
                while ((n = in.read(buffer)) != -1) out.write(buffer, 0, n);
                return out.toString(StandardCharsets.UTF_8.name());
            }
        } catch (Exception e) { return "<p></p>"; }
    }

    private String safeFileName(String title) {
        String value = title == null ? "Katha" : title.trim();
        value = value.replaceAll("[\\\\/:*?\"<>|]", "_").replaceAll("\\s+", "_");
        if (value.isEmpty()) value = "Katha";
        if (value.length() > 70) value = value.substring(0, 70);
        return value;
    }

    // ---------------------------------------------------------------------
    // UI helpers
    // ---------------------------------------------------------------------

    private TextView text(String value, int size, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return v;
    }

    private Button smallButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(12);
        b.setTextColor(Color.rgb(24, 20, 38));
        b.setAllCaps(false);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setElevation(dp(2));
        b.setBackground(round(ACCENT, 15, ACCENT, 1));
        return b;
    }

    private Button iconButton(String value) {
        Button b = new Button(this);
        b.setText(value);
        b.setTextSize(23);
        b.setTextColor(TEXT);
        b.setAllCaps(false);
        b.setPadding(0, 0, 0, dp(3));
        b.setBackground(round(PANEL_2, 14, BORDER, 1));
        return b;
    }

    private GradientDrawable round(int color, int radius, int strokeColor, int strokeWidth) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        if (strokeWidth > 0) d.setStroke(dp(strokeWidth), strokeColor);
        return d;
    }

    private LinearLayout.LayoutParams marginParams(int width, int height, int left, int top, int right, int bottom) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(width < 0 ? width : dp(width), height < 0 ? height : dp(height));
        p.setMargins(dp(left), dp(top), dp(right), dp(bottom));
        return p;
    }

    private EditText dialogInput(String hint, String initial) {
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint(hint);
        input.setText(initial);
        input.setSelectAllOnFocus(true);
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_FLAG_CAP_SENTENCES);
        input.setPadding(dp(20), dp(10), dp(20), dp(10));
        return input;
    }

    private int dp(float value) { return (int) (value * getResources().getDisplayMetrics().density + 0.5f); }
    private void toast(String message) { Toast.makeText(this, message, Toast.LENGTH_LONG).show(); }

    private void hideKeyboard(View view) {
        InputMethodManager imm = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (imm != null) imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    // ---------------------------------------------------------------------
    // WebView-to-native bridge
    // ---------------------------------------------------------------------

    private class EditorBridge {
        @JavascriptInterface
        public void requestFontImport() {
            runOnUiThread(() -> importFont());
        }

        @JavascriptInterface
        public void requestFontManager() {
            runOnUiThread(() -> manageFonts());
        }

        @JavascriptInterface
        public void saveDocument(String title, String html, String plainText, String fontFamily) {
            persistDocument(title, html, plainText, fontFamily);
        }

        @JavascriptInterface
        public void onStats(String plainText) {
            updateCounts(plainText == null ? "" : plainText);
        }

        @JavascriptInterface
        public void onSaving() {
            runOnUiThread(() -> {
                if (saveStateView != null) {
                    saveStateView.setText("Saving…");
                    saveStateView.setTextColor(MUTED);
                }
            });
        }

        @JavascriptInterface
        public String getFontsJson() {
            JSONArray array = new JSONArray();
            try {
                for (FontInfo font : db.getFonts()) {
                    JSONObject item = new JSONObject();
                    item.put("family", font.family);
                    item.put("label", font.label);
                    item.put("fileName", font.fileName);
                    array.put(item);
                }
            } catch (Exception ignored) {}
            return array.toString();
        }

        @JavascriptInterface
        public String getFontBase64(String fileName) {
            try {
                if (fileName == null || fileName.contains("/") || fileName.contains("\\") || fileName.contains("..")) return "";
                File file = new File(new File(getFilesDir(), "fonts"), fileName);
                if (!file.exists() || file.length() > 15L * 1024L * 1024L) return "";
                return Base64.encodeToString(readBytes(file), Base64.NO_WRAP);
            } catch (Exception e) { return ""; }
        }
    }

    // ---------------------------------------------------------------------
    // Database
    // ---------------------------------------------------------------------

    private static class Folder {
        long id; String name;
        Folder(long id, String name) { this.id = id; this.name = name; }
    }

    private static class Note {
        long id; long folderId; String title; String fileName; String preview; String fontFamily; long updatedAt;
        Note(long id, long folderId, String title, String fileName, String preview, String fontFamily, long updatedAt) {
            this.id=id; this.folderId=folderId; this.title=title; this.fileName=fileName; this.preview=preview; this.fontFamily=fontFamily; this.updatedAt=updatedAt;
        }
    }

    private static class FontInfo {
        String family; String label; String fileName;
        FontInfo(String family, String label, String fileName) { this.family=family; this.label=label; this.fileName=fileName; }
    }

    private static class DbHelper extends SQLiteOpenHelper {
        DbHelper(Context context) { super(context, "katha_writer.db", null, 1); }

        @Override public void onCreate(SQLiteDatabase db) {
            db.execSQL("CREATE TABLE folders (_id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, created_at INTEGER NOT NULL)");
            db.execSQL("CREATE TABLE notes (_id INTEGER PRIMARY KEY AUTOINCREMENT, folder_id INTEGER NOT NULL, title TEXT NOT NULL, file_name TEXT NOT NULL, plain_text TEXT NOT NULL DEFAULT '', font_family TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL, updated_at INTEGER NOT NULL)");
            db.execSQL("CREATE INDEX notes_folder_idx ON notes(folder_id)");
            db.execSQL("CREATE TABLE fonts (_id INTEGER PRIMARY KEY AUTOINCREMENT, family TEXT NOT NULL UNIQUE, label TEXT NOT NULL, file_name TEXT NOT NULL)");
        }
        @Override public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {}

        long ensureUnfiledFolder() {
            SQLiteDatabase db = getWritableDatabase();
            try (Cursor c = db.rawQuery("SELECT _id FROM folders WHERE name=? LIMIT 1", new String[]{"Unfiled"})) {
                if (c.moveToFirst()) return c.getLong(0);
            }
            ContentValues v = new ContentValues(); v.put("name", "Unfiled"); v.put("created_at", System.currentTimeMillis());
            return db.insert("folders", null, v);
        }

        ArrayList<Folder> getFolders() {
            ArrayList<Folder> result = new ArrayList<>();
            try (Cursor c = getReadableDatabase().rawQuery("SELECT _id,name FROM folders ORDER BY CASE WHEN name='Unfiled' THEN 0 ELSE 1 END, name COLLATE NOCASE", null)) {
                while (c.moveToNext()) result.add(new Folder(c.getLong(0), c.getString(1)));
            }
            return result;
        }

        long createFolder(String name) {
            ContentValues v = new ContentValues(); v.put("name", name); v.put("created_at", System.currentTimeMillis());
            return getWritableDatabase().insert("folders", null, v);
        }
        void renameFolder(long id, String name) { ContentValues v = new ContentValues(); v.put("name", name); getWritableDatabase().update("folders", v, "_id=?", new String[]{String.valueOf(id)}); }
        void moveFolderNotes(long from, long to) { ContentValues v = new ContentValues(); v.put("folder_id", to); getWritableDatabase().update("notes", v, "folder_id=?", new String[]{String.valueOf(from)}); }
        void deleteFolder(long id) { getWritableDatabase().delete("folders", "_id=?", new String[]{String.valueOf(id)}); }

        long createNote(long folderId, String title) {
            long now = System.currentTimeMillis();
            ContentValues v = new ContentValues();
            v.put("folder_id", folderId); v.put("title", title);
            v.put("file_name", "draft_" + UUID.randomUUID().toString().replace("-", "") + ".html");
            v.put("plain_text", ""); v.put("font_family", ""); v.put("created_at", now); v.put("updated_at", now);
            return getWritableDatabase().insert("notes", null, v);
        }

        Note getNote(long id) {
            try (Cursor c = getReadableDatabase().rawQuery("SELECT _id,folder_id,title,file_name,plain_text,font_family,updated_at FROM notes WHERE _id=?", new String[]{String.valueOf(id)})) {
                if (c.moveToFirst()) return new Note(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getLong(6));
            }
            return null;
        }

        ArrayList<Note> getNotes(long folderId, String query) {
            ArrayList<Note> result = new ArrayList<>();
            String sql = "SELECT _id,folder_id,title,file_name,plain_text,font_family,updated_at FROM notes";
            ArrayList<String> args = new ArrayList<>();
            ArrayList<String> where = new ArrayList<>();
            if (folderId != -1L) { where.add("folder_id=?"); args.add(String.valueOf(folderId)); }
            if (query != null && !query.isEmpty()) { where.add("(title LIKE ? OR plain_text LIKE ?)"); args.add("%"+query+"%"); args.add("%"+query+"%"); }
            if (!where.isEmpty()) sql += " WHERE " + String.join(" AND ", where);
            sql += " ORDER BY updated_at DESC";
            try (Cursor c = getReadableDatabase().rawQuery(sql, args.toArray(new String[0]))) {
                while (c.moveToNext()) result.add(new Note(c.getLong(0), c.getLong(1), c.getString(2), c.getString(3), c.getString(4), c.getString(5), c.getLong(6)));
            }
            return result;
        }

        void updateNote(long id, String title, String plainText, String font) {
            ContentValues v = new ContentValues(); v.put("title", title); v.put("plain_text", plainText); v.put("font_family", font); v.put("updated_at", System.currentTimeMillis());
            getWritableDatabase().update("notes", v, "_id=?", new String[]{String.valueOf(id)});
        }
        void renameNote(long id, String title) {
            ContentValues v = new ContentValues(); v.put("title", title); v.put("updated_at", System.currentTimeMillis());
            getWritableDatabase().update("notes", v, "_id=?", new String[]{String.valueOf(id)});
        }
        void moveNote(long id, long folder) {
            ContentValues v = new ContentValues(); v.put("folder_id", folder); v.put("updated_at", System.currentTimeMillis());
            getWritableDatabase().update("notes", v, "_id=?", new String[]{String.valueOf(id)});
        }
        void deleteNote(long id) { getWritableDatabase().delete("notes", "_id=?", new String[]{String.valueOf(id)}); }

        void addFont(String family, String label, String fileName) {
            ContentValues v = new ContentValues(); v.put("family", family); v.put("label", label); v.put("file_name", fileName);
            getWritableDatabase().insert("fonts", null, v);
        }
        ArrayList<FontInfo> getFonts() {
            ArrayList<FontInfo> result = new ArrayList<>();
            try (Cursor c = getReadableDatabase().rawQuery("SELECT family,label,file_name FROM fonts ORDER BY label COLLATE NOCASE", null)) {
                while (c.moveToNext()) result.add(new FontInfo(c.getString(0), c.getString(1), c.getString(2)));
            }
            return result;
        }
        FontInfo getFontByFamily(String family) {
            if (family == null || family.isEmpty()) return null;
            try (Cursor c = getReadableDatabase().rawQuery("SELECT family,label,file_name FROM fonts WHERE family=? LIMIT 1", new String[]{family})) {
                if (c.moveToFirst()) return new FontInfo(c.getString(0), c.getString(1), c.getString(2));
            }
            return null;
        }
        void deleteFont(String family) { getWritableDatabase().delete("fonts", "family=?", new String[]{family}); }
    }
}
