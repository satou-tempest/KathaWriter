# Katha Writer — Android Novel Writing Studio

**Version:** 0.1-beta.2  
**Platform:** Android 8.0+ (API 26+)  
**Storage:** Local-first; manuscript bodies are stored as UTF-8 HTML files and metadata is stored in SQLite.

Katha Writer is an Android-only novel-writing workspace. It is designed for long manuscripts, Burmese Unicode writing, custom typography, and clear project organization.

## What's new in 0.1-beta.2

- Fixed a CSS rule that forced every manuscript element to inherit the document font. That rule prevented inline font overrides from rendering.
- Replaced the browser-native font dropdown with a custom font-library sheet.
- Added **selection-level font formatting**: select a word, dialogue, line, or paragraph, tap **Aa Font**, then tap a font. Only the selected range is changed.
- Added a separate **Set Default** action for each font. This sets the note's base font without removing font choices already applied to selected ranges.
- Added per-font Burmese previews and a Manage Fonts shortcut in the font sheet.
- Added font-load failure feedback instead of silently applying a missing font.
- Reworked the editor toolbar with rounded grouped controls and a custom font sheet.
- Refreshed the home screen and folder tiles with folder icons and note counts.
- Added a new adaptive launcher icon.
- EPUB font embedding now includes all imported fonts detected as used in the manuscript when the user explicitly enables embedding (font redistribution permissions still apply).
- Bumped Android version code to 2 and version name to 0.1-beta.2.

## Using multiple fonts in one note

1. Open a note and import one or more `.ttf` or `.otf` files from **Aa Font → Import font**.
2. In the font library, tap **SET DEFAULT** beside the font you want for normal narration.
3. Write normally using that default font.
4. Select a specific dialogue, line, or paragraph.
5. Tap **Aa Font** and tap the font you want for that selection.
6. Repeat for other passages. Existing selections retain their own inline font formatting.

The editor stores inline font formatting in the manuscript HTML. The default font is stored separately as note metadata.

## Burmese typography

- UTF-8 manuscript storage.
- Android WebView text shaping for Myanmar Unicode/OpenType fonts.
- System fallback stack: Noto Sans Myanmar, Myanmar Text, Padauk.
- TTF and OTF custom font import.
- ICU Myanmar-aware word segmentation and grapheme-aware character counting in the native app.

Rendering quality depends on each imported font's Unicode coverage and OpenType shaping tables. Some legacy Zawgyi-only fonts or unusual OTF/CFF fonts may not render as expected. Prefer Unicode Myanmar fonts.

## Long manuscripts

There is no hardcoded word-count ceiling. Each manuscript is stored separately as a UTF-8 HTML file rather than being inserted as one large SQLite text value. Practical limits still depend on available device storage and WebView memory/rendering performance. Very large documents should be stress-tested on the target phone before relying on them as the only copy.

## Export

- **PDF:** Android system print interface → Save as PDF.
- **EPUB 3:** Reflowable EPUB package. Optional custom-font embedding is off by default. Only embed fonts when their licences permit redistribution.

## Build on GitHub from Android

1. Upload this ZIP file to the root of a GitHub repository. Keep only one Katha Writer source ZIP in the repository so the workflow extracts the correct archive.
2. The repository's existing `.github/workflows/build-debug-apk.yml` workflow extracts the ZIP and locates the Gradle project automatically.
3. Open **Actions** and run **Build Katha Writer debug APK**.
4. Download the generated APK from the workflow's Artifacts section.

The ZIP contains the Android project at its archive root. Do not add an extra `KathaWriter/` wrapper directory around the project.

## Important beta limitations

- The editor is WebView-based; a future version should add virtualized rendering for extremely large manuscripts.
- Font import currently supports TTF and OTF, not variable WOFF/WOFF2/TTC collections.
- Applying a font to a selection uses Chromium/WebView editing commands and requires the font to load successfully.
- A debug APK built on a fresh GitHub runner may not share the signing key of a previously built debug APK. Back up/export manuscripts before uninstalling an older build.
- Always keep independent backups of important manuscripts.

## v0.1-beta.3 launcher icon

This build includes a custom fantasy-themed Katha Writer launcher icon, wired into Android adaptive-icon resources and density-specific mipmap fallbacks. The launcher label remains **Katha Writer**.
