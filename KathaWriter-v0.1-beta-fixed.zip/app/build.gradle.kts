plugins {
    id("com.android.application")
}

android {
    namespace = "com.katha.writer"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.katha.writer"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1-beta"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildFeatures {
        buildConfig = true
    }
}
