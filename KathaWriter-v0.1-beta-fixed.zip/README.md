# Katha Writer — v0.1-beta

An Android-only, local-first writing studio prototype focused on long-form Burmese and multilingual fiction writing.

## v0.1-beta scope

- Rich-text manuscript editor with paragraph/heading/quote styles, bold, italic, underline, strikethrough, lists, alignment, undo and redo.
- Burmese Unicode writing in the Android WebView editor, using Myanmar-friendly system fallbacks and normal Chromium text shaping.
- Import custom `.ttf` and `.otf` fonts from Android's document picker. Fonts are stored privately in the app and loaded only when selected. Each note remembers its selected font.
- Folders: create, rename, delete, filter, move notes, and an undeletable `Unfiled` folder.
- Notes: create, rename, search, edit, delete, and autosave.
- Live word count using Android ICU word segmentation with the Myanmar locale; live character counts use grapheme clusters, plus a count excluding whitespace.
- PDF export through Android's system print flow (choose **Save as PDF** in the print destination picker).
- EPUB 3 export with a navigation document and optional embedding of the selected custom font. Font embedding is off by default because font licences may prohibit redistribution.
- Offline-first storage. Manuscript HTML is stored as separate UTF-8 files; SQLite stores note/folder/font metadata and searchable text. There is no app-imposed word-count ceiling.

## Important limitations in this beta

- There is **no fixed 100,000-word limit**, but no phone app can promise literally infinite text. Storage, RAM, WebView/Chromium rendering and document size determine the practical ceiling. Very large chapters should be tested on the target phone.
- The editor is a single continuous document surface, not a virtualized/page-chunked editor. Extremely large documents can eventually become slower to edit even though the storage layer has no small fixed cap.
- Myanmar Unicode is the intended format. Legacy Zawgyi text is not converted automatically. Use a Unicode Burmese keyboard and a Unicode-capable TTF/OTF font.
- Supported custom font files are `.ttf` and `.otf` (15 MB maximum per font in this beta). WOFF/WOFF2, TTC collections, per-character font runs, variable-font axis controls and a full font specimen browser are not included yet.
- The font selection applies to the whole note, not selected words or individual paragraphs.
- EPUB conversion normalizes the editor's HTML to XHTML. Complex pasted HTML may need checking in an EPUB reader.
- PDF output uses Android's print service; the exact print dialog and PDF destination depend on the Android device's print provider.
- v0.1 does not yet include cloud sync, version history, nested folders, full project backup/restore, images, tables, footnotes, or a desktop companion.

## Project details

- Package: `com.katha.writer`
- Minimum Android: API 26 (Android 8.0)
- Compile/target SDK: API 36
- Android Gradle Plugin: 9.5.0
- Gradle: 9.6.0
- Java: 17
- Runtime dependencies: Android platform APIs only; no third-party runtime library is required.

## Build with GitHub Actions (phone-friendly route)

The source includes `.github/workflows/build-debug-apk.yml`. Upload the project files to the root of your GitHub repository for the cleanest layout. The workflow also detects the project if it is nested one folder down (for example, `KathaWriter/settings.gradle.kts`), which prevents the “does not contain a Gradle build” error from an accidental extra folder:

1. Open the repository on GitHub and go to **Actions**.
2. Enable Actions for the repository if GitHub asks.
3. Select **Build Katha Writer debug APK**.
4. Press **Run workflow**.
5. Open the completed run and download the artifact named `katha-writer-v0.1-beta-debug`.
6. Extract the artifact and install `app-debug.apk` on the Android phone. Android may ask you to allow installation from the browser or file manager used to open it.

The workflow compiles a debug APK. It is for testing, not a Play Store release. A release build should later be signed with a private upload key that is kept outside the repository.

## Local Android Studio build

Open this folder as an Android Studio project, use JDK 17, install Android SDK Platform 36 and Build Tools 36.0.0, then run the `app` configuration. The Gradle distribution is 9.6.0. This source archive intentionally does not include a Gradle wrapper JAR; the included GitHub Actions workflow installs Gradle directly.

## First-device test checklist

1. Create a folder and a note inside it.
2. Type a Burmese Unicode paragraph using the phone keyboard. Confirm combining marks render correctly.
3. Import a Burmese Unicode `.ttf` or `.otf` font and select it in the editor toolbar.
4. Type mixed Burmese and English text; watch word and grapheme counts update.
5. Close the note, reopen it, and verify the content and font choice persist.
6. Paste a long test manuscript (start with 10,000–20,000 words, then increase) and check editing responsiveness and saved content.
7. Export to PDF and open the resulting file; inspect Burmese glyphs and page breaks.
8. Export to EPUB and open it in an EPUB reader; test both with and without custom-font embedding.

## Data and privacy

All note and font files remain in the app's private on-device storage. This app does not request internet access. Uninstalling the app can remove its private data; export important manuscripts regularly until a dedicated project backup/restore feature is added.
